from vehicle import Vehicle

class Garage:
    def __init__(self):
        self.parked = None

    def set_vehicle(self, vehicle: Vehicle):
        self.parked = vehicle

    def __str__(self):
        if self.parked:
            return f"Description of the parked vehicle ...\n{self.parked}"
        else:
            return "No vehicle parked"