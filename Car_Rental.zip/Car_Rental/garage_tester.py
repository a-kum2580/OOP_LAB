from garage import Garage
from truck import Truck

class GarageTester:
    def get_example(self):
        truck = Truck("black")
        garage = Garage()
        garage.set_vehicle(truck)
        return garage

if __name__ == "__main__":
    tester = GarageTester()
    garage = tester.get_example()
    print(garage)